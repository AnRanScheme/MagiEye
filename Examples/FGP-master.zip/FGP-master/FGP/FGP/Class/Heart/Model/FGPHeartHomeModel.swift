//
//  FGPHeartHomeModel.swift
//  FGP
//
//  Created by BriceZH on 2018/10/29.
//  Copyright © 2018 BriceZhao. All rights reserved.
//

import UIKit

class FGPHeartHomeModel: NSObject {

}
