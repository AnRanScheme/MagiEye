//
//  FGPHeartHomeView.swift
//  FGP
//
//  Created by BriceZH on 2018/10/29.
//  Copyright © 2018 BriceZhao. All rights reserved.
//

import UIKit

class FGPHeartHomeView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
