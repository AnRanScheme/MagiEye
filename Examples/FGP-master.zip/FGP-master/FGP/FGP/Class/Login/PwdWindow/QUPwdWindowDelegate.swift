//
//  QUPwdWindowDelegate.swift
//  FGP
//
//  Created by briceZhao on 2018/8/31.
//  Copyright © 2018年 BriceZhao. All rights reserved.
//

import UIKit

protocol QUPwdWindowDelegate: NSObjectProtocol {
    
    
}
