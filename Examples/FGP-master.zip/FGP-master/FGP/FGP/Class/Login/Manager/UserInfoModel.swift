//
//  UserInfoModel.swift
//  FGP
//
//  Created by briceZhao on 2018/9/3.
//  Copyright © 2018年 BriceZhao. All rights reserved.
//

import UIKit

class UserInfoModel: NSObject {
    
    var uid: String?
    
    var nick_name: String?
    
    var mobile_num: String?
}
