//
//  CommunotyModel.swift
//  FGP
//
//  Created by anran on 2018/8/27.
//  Copyright © 2018年 BriceZhao. All rights reserved.
//

import UIKit

class FGPCommunotyModel {
    
    var title: String?
    var time: String?
    var content: String?
    var photoImageString: String?
    
    var userComment: [String]?
    
}

